﻿using System;
using System.Collections.Generic;
using System.Text;
using Zoo;

namespace _2._Zoo
{
    public class Reptile:Animal
    {
        public Reptile(string name)
            :base(name)
        {

        }


    }
}
